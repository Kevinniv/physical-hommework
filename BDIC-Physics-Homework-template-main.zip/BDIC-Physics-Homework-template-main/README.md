**This is not an official template**

**这不是一个官方的模板**

---

### 使用方法

如果你的电脑上有git，你可以直接输入
```
git clone https://github.com/dqhl76/BDIC-Physics-Homework-template.git
```
并对其中的tex文件进行修改即可

如果你的电脑上没有git，你可以选择 Code -> Download Zip

如果你的github访问非常慢，我也推荐你直接点击下载
[点我下载](https://cowtransfer.com/s/f0baf2605e9049)

---

### Demo
![image.png](https://i.loli.net/2021/10/17/D1arfBPCd7LTkjY.png)
![image.png](https://i.loli.net/2021/10/17/5ASgpP9Iloztj1E.png)

